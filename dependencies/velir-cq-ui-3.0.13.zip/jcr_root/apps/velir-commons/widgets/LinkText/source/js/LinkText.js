//create widget namespace
CQ.Ext.ns('VelirWidgets');

VelirWidgets.SimpleLinkText = CQ.Ext.extend(CQ.form.DialogFieldSet, {

	/**
	 * Constructor add the widget items to config
	 * @param config
	 */
	constructor: function (config) {
		var config = config || {};
		if (!config.name) {
			config.name = "./simpleLinkText";
		}
		CQ.Util.applyDefaults(config, {
			defaults: {
				anchor: "100%"
			},
			items: [
				{
					xtype: "textfield",
					itemId: "textId",
					name: config.name + "/text",
					fieldLabel: config.textLabel? config.textLabel : "Text",
					allowBlank: config.allowEmptyText? true : false
				},
				{
					xtype: "pathfield",
					name: config.name + "/link",
					fieldLabel: "Link",
					allowBlank: false,
					rootPath: config.rootPath,
					forceSelection : config.forceSelection
				},
				{
					xtype: "hidden",
					name: config.name + "/sling:resourceType",
					value: "velircommons/components/content/simplelinktext",
					ignoreData: true
				}

			]
		});
		VelirWidgets.SimpleLinkText.superclass.constructor.call(this, config);
	}
});
CQ.Ext.reg("simplelinktext", VelirWidgets.SimpleLinkText);

VelirWidgets.SimpleLinkDateText = CQ.Ext.extend(CQ.form.DialogFieldSet, {

	/**
	 * Constructor add the widget items to config
	 * @param config
	 */
	constructor: function (config) {
		var config = config || {};
		if (!config.name) {
			config.name = "./simpleLinkText";
		}
		CQ.Util.applyDefaults(config, {
			defaults: {
				anchor: "100%"
			},
			items: [
				{
					xtype: "pathfield",
					name: config.name + "/link",
					fieldLabel: "Link",
					allowBlank: false,
					rootPath: config.rootPath,
					forceSelection : config.forceSelection,
					fieldDescription:config.linkFieldDesc
				},
				{
					xtype: "textfield",
					itemId: "textId",
					name: config.name + "/text",
					fieldLabel: config.textLabel? config.textLabel : "Text",
					allowBlank: config.allowEmptyText? true : false
				},
				{
					xtype: "datetime",
					name: config.name + "/date",
					fieldLabel: "Date",
					allowBlank: false
				},
				{
					xtype: "hidden",
					name: config.name + "/sling:resourceType",
					value: "velircommons/components/content/simplelinkdatetext",
					ignoreData: true
				}

			]
		});
		VelirWidgets.SimpleLinkDateText.superclass.constructor.call(this, config);
	}
});
CQ.Ext.reg("simplelinkdatetext", VelirWidgets.SimpleLinkDateText);

VelirWidgets.MultiLinkText = CQ.Ext.extend(CQ.form.DialogFieldSet, {
	constructor: function (config) {
		var config = config || {};
		var allowEmptyText = config.allowEmptyText? true :false;
		var textLabel = config.textLabel? config.textLabel : "Text";
		if (!config.name) {
			config.name = "links"
		}
		CQ.Util.applyDefaults(config, {
			items: [
				{
					xtype: "velirmultidialogfield",
					name: config.name,
					hideLabel: true,
					maxItems: config.maxItems,
					itemConfig: {
						itemDefaultDisplayText: "Click to edit a link",
						itemDisplayName: "./text",
						itemResourceType: "velircommons/components/content/simplelinktext",
						itemPrefix: config.name + "/link",
						itemTitle: "Link",
						itemDialogConfig: {
							xtype:"dialog",
							title:"Edit link",
							height:150,
							items: [
								{
									xtype: "panel",
									items: [
										{
											xtype:"simplelinktext",
											border:false,
											name:".",
											allowEmptyText: allowEmptyText,
											textLabel : textLabel,
											forceSelection : config.forceSelection,
											rootPath: config.rootPath
										}
									]
								}
							]
						}
					}
				}
			]
		});
		VelirWidgets.MultiLinkText.superclass.constructor.call(this, config);
	}
});

CQ.Ext.reg("multilinktext", VelirWidgets.MultiLinkText);