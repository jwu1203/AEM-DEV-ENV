CQ.Ext.ns('VelirWidgets');

VelirWidgets.SmartImage =CQ.Ext.extend(CQ.html5.form.SmartImage, {
    createRefUrl : function(refFileInfo){
        var ext = "";
        for (var r in refFileInfo.renditions) {
            var rPath = CQ.html5.form.SmartFile.DAM_RENDITIONS_PATH + r;
            if (rPath == this.renditionSuffix) {
                // suffix defined incl. extension resp. no extension (e.g. "original")
                break;
            }
            if (rPath.indexOf(this.renditionSuffix) == 0) {
                ext = r.substring(r.lastIndexOf("."));
                break;
            }
        }
        var url = refFileInfo.dataPath + this.renditionSuffix + ext;
        return CQ.HTTP.externalize(CQ.shared.HTTP.encodePath(url), true);
    }
});
CQ.Ext.reg("velirsmartimage", VelirWidgets.SmartImage);

VelirWidgets.ConstrainedImage = CQ.Ext.extend(VelirWidgets.SmartImage, {

    constructor : function(config) {
        VelirWidgets.ConstrainedImage.superclass.constructor.call(this, config);
        if (config.name && config.includeResourceType) {
            var pathParts = config.name.split("/");
            var pathName = ".";
            for (var i = 1; i < pathParts.length - 1; i++) {
                pathName += "/" + pathParts[i];
            }
            var addHidden = function(hiddenName, hiddenValue){
                var hiddenInput = new CQ.Ext.form.Hidden({
                    "ignoreData" : true,
                    "name" : pathName + "/" + hiddenName,
                    "value" : hiddenValue
                });
                this.items.add(hiddenInput.getId(), hiddenInput);
            };

            if(config.includeResourceType){
                addHidden.call(this, "sling:resourceType", "foundation/components/image");
            }
        }
    }
});
CQ.Ext.reg("velirconstrainedimage", VelirWidgets.ConstrainedImage);