(function(ns, document, $, Granite, undefined) {
	'use strict';
	var registry = $(window).adaptTo("foundation-registry");
	registry.register("foundation.validation.selector", {
		submittable: ".velir-tags",
		candidate: ".velir-tags:not([disabled]):not([readonly])",
		exclusion: ".velir-tags *"
	});
	var getField = function(el){
		return $(el).find('.js-coral-pathbrowser-input').adaptTo("foundation-field");
	};
	registry.register("foundation.validation.validator", {
		selector: ".velir-tags",
		validate: function(el) {
			var $el = $(el);
			var $tagsPicker = $el.find("ul.js-TagsPickerField-tagList"),
				maxTags = $el.data('max-tags');

			if(!maxTags || maxTags === 0){
				return;
			}

			var tagList = $tagsPicker.find('.coral-TagList-tag');

			return (tagList.length > maxTags
				? "Max exceeded, allowed : " + maxTags : undefined);
		},
		show : function(el, message, ctx){
			getField(el).setInvalid(true);
			ctx.next();
		},
		clear : function (el, ctx) {
			getField(el).setInvalid(false);
			ctx.next();
		}
	});
	var checkValidity = function(){
		var api = $('.velir-tags').adaptTo("foundation-validation");
		if(api){
			api.checkValidity();
			api.updateUI();
		}
	};
	$(document).on('click', '.velir-tags .js-TagsPickerField-tagList', checkValidity) ;
	$(document).on('change', '.velir-tags', checkValidity);
})(window.velirTouchUI = window.velirTouchUI || {}, document, Granite.$, Granite);
