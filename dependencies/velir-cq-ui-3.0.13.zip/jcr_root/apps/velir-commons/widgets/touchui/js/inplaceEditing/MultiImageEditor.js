/**
 * In place editor for multi image that allows you to crop/rotate components with arbitrary # of images.
 *  Requires configuration for image sub-nodes and for images to have a drop config css class.
 *    - image class cq-dd-image-multiImage${tile.name}
 *
 *  <cq:inplaceEditing
 *    jcr:primaryType="cq:InplaceEditingConfig"
 *    active="{Boolean}true"
 *    editorType="multiImage">
 *      <config jcr:primaryType="nt:unstructured"
 *        imagePrefix="items/item">
 *      </config>
 *  </cq:inplaceEditing>
 *
 *  JCR structure of component
 *    component
 *      items
 *        item1
 *          image
 *        item2
 *          image
 *        item3
 */
(function(ns, window, document, $, Granite, undefined) {

  ns.MultiImageEditor = function(options){
    //Noop
  };
  ns.MultiImageEditor.prototype.setComponentInfo = function(config){
    this.componentInfo = Granite.HTTP.eval(config.path + ".infinity.json");
  };
  ns.MultiImageEditor.prototype.setUpDropTargets = function(editable, editConfig){
    var dropTarget = editConfig.dropTarget? editConfig.dropTarget : [];
    var childNodeName = this.imageParts[0];
    var namePrefix = this.imageParts[1];
    var multiNode = this.componentInfo[childNodeName];
    var $component = editable.dom;
    if(multiNode){
      var dynamicDrops = [];
      Object.keys(multiNode).forEach(function (multiItemName) {
        if(multiItemName.startsWith(namePrefix)){
          var multiItem = multiNode[multiItemName];
          var imageId = "-multiImage" + multiItemName;
          if ($component.find(".cq-dd-image" + imageId).length > 0) {
            _.each(multiItem, function (itemData, itemName) {
              if (itemData['sling:resourceType'] === "foundation/components/image") {
                var imageNameParam = "./" + childNodeName + "/" + multiItemName + "/" + itemName;
                var newDropTarget = {accept: ["image/.*"], groups: [], overlay: $('<div/>')};
                newDropTarget.id = imageId;
                newDropTarget.name = imageNameParam + "/fileReference";
                var params = {};
                params[imageNameParam + "/imageCrop"] = itemData.imageCrop ? itemData.imageCrop : "";
                params[imageNameParam + "/imageMap"] = itemData.imageMap ? itemData.imageMap : "";
                params[imageNameParam + "/imageRotate"] = itemData.imageRotate ? itemData.imageRotate : "";
                params[imageNameParam + "/sling:resourceType"] = "foundation/components/image";
                newDropTarget.params = params;
                dynamicDrops.push(newDropTarget);
                dropTarget.push(newDropTarget)
              }
            });
          }
        }
      });
      this.dynamicDrops = dynamicDrops;
      editConfig.dropTarget = dropTarget;
    }
  };
  ns.MultiImageEditor.prototype.setChildEditors = function(){
    var editors = [];
    var cnt = 1;
    _.each(this.dynamicDrops, function (dynamicDrop) {
      editors.push({type: 'image', title:"Image " + cnt, id: dynamicDrop.id});
      cnt++;
    });
    this.childEditors = editors;
  };
  ns.MultiImageEditor.prototype.setupInplaceEditor = function(editConfig){
    var inplaceEditingConfig = editConfig.inplaceEditingConfig;
    inplaceEditingConfig.childEditors = this.childEditors? this.childEditors : [];
    inplaceEditingConfig.editorType = "hybrid"; //Post registry -> allows us to hide as a hybrid
  };
  ns.MultiImageEditor.prototype.setUp = function(editable){
    var config = editable.config;
    var ipeConfig = config.ipeConfig;
    this.imagePrefix = ipeConfig.imagePrefix;
    this.imageParts = this.imagePrefix.split("/");
    this.setComponentInfo(config);

    var editConfig = config.editConfig;
    this.setUpDropTargets(editable, editConfig);
    editable.dropTargets = editConfig.dropTarget;
    this.setChildEditors();
    this.setupInplaceEditor(editConfig);

    this.hybrid = new Granite.author.editor.HybridEditor(this.childEditors);
    this.hybrid.setUp(editable);
    editable._buildConfig(config);
  };
  ns.MultiImageEditor.prototype.tearDown = function(editable){
    this.hybrid.tearDown(editable);
  };
  if(Granite.author) {
      Granite.author.editor.register('multiImage', new ns.MultiImageEditor())
  }
})(window.velirTouchUI = window.velirTouchUI || {}, window, document, Granite.$, Granite);
