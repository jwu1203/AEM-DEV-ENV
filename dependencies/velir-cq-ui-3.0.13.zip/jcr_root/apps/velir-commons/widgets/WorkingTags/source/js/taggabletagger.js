/**
 * Created by suma.kollipara on 7/20/2015.
 */
CQ.Ext.ns('VelirWidgets');

/**
 * tag input widget that extends the OOTB widget to set the cq:Taggable mixin on the node it stores to
 * @type {*}
 */
VelirWidgets.TaggableTags = CQ.Ext.extend(CQ.tagging.TagInputField, {

    constructor: function(config) {
        var modifiedConfig = config;

        // if this name is not the normal tag property name, we have to store it on a node underneath the current
        if ("./cq:tags" != config.name) {
            this.originalPropertyName = config.name;

            modifiedConfig = CQ.Util.merge(config, {
                'name' : config.name + "/cq:tags"
            })
        }

        VelirWidgets.TaggableTags.superclass.constructor.call(this, modifiedConfig);
    },

    updateHiddenFields: function () {
        VelirWidgets.TaggableTags.superclass.updateHiddenFields.call(this, arguments);

        if (this.originalPropertyName) {
            var mixinProp = new CQ.Ext.form.Hidden({
                'name' : this.originalPropertyName + "/jcr:mixinTypes",
                'value' : ['cq:Taggable']
            });
            this.add(mixinProp);
            this.hiddenFields.push(mixinProp);
            this.doLayout();
        }
    }
});

CQ.Ext.reg('workingtags', VelirWidgets.TaggableTags);
