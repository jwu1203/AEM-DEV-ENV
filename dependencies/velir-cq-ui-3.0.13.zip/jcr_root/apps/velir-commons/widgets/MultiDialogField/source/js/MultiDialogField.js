//create widget namespace
CQ.Ext.ns('VelirWidgets');

VelirWidgets.MultiDialogField = CQ.Ext.extend(CQ.form.CompositeField, {
    /**
     * @cfg {Object/Object[]} itemConfig
     * The configuration that will be passed to each item.
     */
    itemConfig: null,

    /**
     * @cfg {String} itemPrefix
     * The prefix that will be used for each subnode (Defaults to item).
     */
    itemPrefix: null,

    /**
     * @cfg {Number} maxItems
     * The maximum number of items a user can add (Defaults to 8).
     */
    maxItems: null,

    /**
     * The panel that will hold our configured items.
     * @type CQ.Ext.Panel
     * @private
     */
    itemsPanel: null,

    /**
     * The toolbar that will hold our buttons.
     * @type CQ.Ext.Toolbar
     * @private
     */
    toolbar: null,

    /**
     * The name of the property that will contain the value for our display field.  This will be used to load the proper display value when this widget is first opened.
     * @type {Object}
     * @private
     */
    itemDisplayNames: null,

    /**
     * Flag indicating if we already loaded our content or not.
     * @type {Boolean}
     * @private
     */
    contentLoaded: false,

    /**
     * The item prefix split into parts (allows support for partial paths like videos/video)
     * @type {Object}
     * @private
     */
    itemPrefixes: null,

    parentItem: null,

    removedItems: [],

    itemPositions: [],

    constructor: function (config) {
        var that = this;

        //apply any default configuration
        CQ.Util.applyDefaults(config, that.buildDefaults());

        //guarantee itemConfig is an array
        if (Object.prototype.toString.call(config.itemConfig) !== '[object Array]') {
            config.itemConfig = [config.itemConfig];
        }

        //hard set the xtype for our items and generate itemPrefixParts
        for (var i = 0; i < config.itemConfig.length; i++) {
            config.itemConfig[i].xtype = 'velirmultidialogfield.item';

            if (!config.itemConfig[i].itemResourceType) {
                config.itemConfig[i].itemResourceType = 'foundation/components/image';
            }

            config.itemPrefixes[config.itemConfig[i].itemResourceType] = {
                'prefix': config.itemConfig[i].itemPrefix || config.itemPrefix,
                'parts': config.itemConfig[i].itemPrefix ? config.itemConfig[i].itemPrefix.split('/') : config.itemPrefix.split('/')
            };

            //lets look for our item display name so we can load all our content properly.
            var displayName = that.findDisplayPropName(config.itemConfig[i]);
            if (displayName) {
                config.itemConfig[i].itemDisplayName = displayName;

                config.itemDisplayNames[config.itemConfig[i].itemResourceType] = {
                    'name': displayName.replace('./', '')
                };
            }
        }

        //create our items panel and buttons
        that.itemsPanel = that.buildItemPanel();

        that.parentItem = that.findParentByType();
        //build toolbar
        that.toolbar = that.buildToolbar(config);

        //add our items panel and our toolbar buttons to the config.
        config.items = [
            that.itemsPanel,
            that.toolbar
        ];

        //call our superclass constructor using our configuration
        VelirWidgets.MultiDialogField.superclass.constructor.call(this, config);
    },

    /**
     * Builds defaults object for this widget.  Here for easily overriding if necessary.
     * @returns {Object}
     */
    buildDefaults: function () {
        return {
            'border': false,
            'itemConfig': [
                {}
            ],
            'itemPrefix': 'item',
            'maxItems': 8,
            'itemDisplayNames': {},
            'itemPrefixes': {}
        };
    },

    /**
     * Builds the panel to hold our items.
     * @returns {*}
     */
    buildItemPanel: function () {
        return CQ.Util.build({
            'bodyBorder': false,
            'layout': 'velirmultidialogfielditems',
            'xtype': 'panel'
        });
    },

    /**
     * Builds the toolbar containing buttons for controlling this widget functionality.
     * @returns {*}
     */
    buildToolbar: function (config) {
        return CQ.Util.build(
            {
                'xtype': 'toolbar',
                'cls': 'cq-multifield-toolbar',
                'items': [
                    '->',
                    this.buildAddButton(config)
                ]
            }
        );
    },

    /**
     * Builds the add button for addition to the toolbar
     * @param config The main widget config
     * @returns {CQ.Ext.Action}
     */
    buildAddButton: function (config) {
        var that = this;

        //define reusable button handler
        var addBtnHandler = function () {
            that.addItem(that.getItemConfig(that.generateNewDataPath(this.itemResourceType), {
                'itemNumber': that.itemsPanel.items.getCount() + 1
            }));
        };

        //define menu items for add button
        var menuItems = [];
        var defaultItemIndex = 0;
        for (var i = 0; i < config.itemConfig.length; i++) {
            menuItems.push({
                'text': 'Add ' + VelirWidgets.MultiDialogFieldUtil.getItemFriendlyTitle(config.itemConfig[i]),
                'itemIndex': i,
                'itemResourceType': config.itemConfig[i].itemResourceType,
                'handler': function () {
                    if (this.parentMenu) {
                        defaultItemIndex = this.itemIndex;
                        this.parentMenu.ownerCt.setText(this.text);
                    }
                    addBtnHandler.call(this);
                }
            });

            if (config.itemConfig[i].itemIsDefault) {
                defaultItemIndex = i;
            }
        }

        //define the add action which will represent the add button
        var addActionConfig = {
            'text': menuItems[defaultItemIndex].text,
            'menu': {
                'xtype': 'menu',
                'items': menuItems
            }
        };
        if (config.itemConfig.length == 1) {
            addActionConfig = {
                'text': 'Add Item',
                'itemResourceType': config.itemConfig[0].itemResourceType,
                'handler': addBtnHandler
            }
        }

        //create add action
        var addAction = new CQ.Ext.Action(addActionConfig);
        if (config.itemConfig.length > 1) {
            addAction.xtype = 'tbsplit';
            addAction.setHandler(function () {
                menuItems[defaultItemIndex].handler.call(menuItems[defaultItemIndex]);
            });
        }

        return addAction;
    },

    submitDialog: function () {
        var ic = this.itemsPanel.items.items;

        for (var i =0; i < ic.length; i++){
            var item = ic[i];
            var dataPath = item.dataPath;

            //submit the dialog form
            var idialog = item.itemDialog;
            var params = {
                    './sling:resourceType': item.itemResourceType,
                    './jcr:created': '',
                    './jcr:createdBy': '',
                    './jcr:lastModified': '',
                    './jcr:lastModifiedBy': ''
                };
            if (idialog !== undefined && idialog !== null) {
                var dialogParams = idialog.form.getValues();
                $.extend(params, dialogParams);
            }
            CQ.HTTP.post(dataPath, null,params );
        }

        //delete the removed nodes from jcr
        for (var i=0; i< this.removedItems.length; i++) {
            //post delete to jcr
            CQ.HTTP.post(this.removedItems[i], null, {
                ':operation': 'delete'
            });
        }
        this.removedItems = [];

        //persist any ordering change to the items
        var itemPos = this.itemPositions;
        for (var i=0; i<itemPos.length; i++) {
            var pos = itemPos[i];
            //reorder our item in the jcr
            CQ.HTTP.post(pos.dp, null, {
                ':order': pos.pos
            });
        }
        this.itemPositions = [];
    },

    resetDialog: function(arg) {
        var ic = this.itemsPanel.items.items;

        for (var i =0; i < ic.length; i++) {
            var item = ic[i];
            item.itemDialog = null;
        }
    },

    initComponent: function () {
        var that = this;

        var beforeDialogSubmit = function() {
            that.submitDialog();
        };

        var dialogClose = function(arg) {
            that.resetDialog(arg);
        }

        var dialog = this.findParentByType('dialog', true);

        this.mon(dialog, 'beforesubmit', beforeDialogSubmit, null, null);

//        this.mon(dialog, 'beforehide', dialogClose, null, null);

        //call our superclass initComponent method.
        VelirWidgets.MultiDialogField.superclass.initComponent.call(this);
    },

    processRecord: function (record, path) {
        //if content has been loaded, we need to clear our items and re-add them.
        //this is because data may change via another process while the dialog is
        //cached on the page.
        if (this.contentLoaded) {
            this.itemsPanel.removeAll(true);
            this.itemsPanel.doLayout();
        }

        if (this.fireEvent('beforeloadcontent', this, record, path) === false) {
            return;
        }

        //detect items in our data and grab them
        var detectedItems = [];
        var data = record.data;

        var itemPrefixParts;
        for (var localItemPrefix in this.itemPrefixes) {
            if (!this.itemPrefixes.hasOwnProperty(localItemPrefix)) {
                continue;
            }

            itemPrefixParts = this.itemPrefixes[localItemPrefix].parts;
            break;//we only need the first set of parts (all prefixes should share any configured subpaths.)
        }
        if (itemPrefixParts.length > 1) {
            for (var i = 0; i < itemPrefixParts.length - 1; i++) {
                data = data[itemPrefixParts[i]];
            }
        }

        //loop through items in our data object and pull out our items
        for (var k in data) {
            for (var localItemPrefix in this.itemPrefixes) {
                if (!this.itemPrefixes.hasOwnProperty(localItemPrefix)) {
                    continue;
                }

                if (data.hasOwnProperty(k) && k.indexOf(this.getNodePrefix(localItemPrefix)) == 0 && parseInt(k.substring(this.getNodePrefix(localItemPrefix).length)) % 1 === 0 && data[k]) {
                    detectedItems.push({
                        'nodeName': k,
                        'itemData': data[k]
                    });
                    break;
                }
            }
        }

        //go through each item and add
        var itemNumber = 1;
        for (var i = 0; i < detectedItems.length; i++) {
            //get item path
            var detectedResourceType = detectedItems[i].itemData['sling:resourceType'];
            if (!detectedResourceType) {//skip any items without a sling:resourceType
                continue;
            }
            var itemPath = path + this.getItemPrefixPath(detectedResourceType) + '/' + detectedItems[i].nodeName;

            //get display text
            var displayText;
            if (this.itemDisplayNames[detectedResourceType] && this.itemDisplayNames[detectedResourceType].name) {
                var dispNameStruct = this.itemDisplayNames[detectedResourceType].name.split('/');
                var localItemData = detectedItems[i].itemData;
                for (var j = 0; j < dispNameStruct.length - 1; j++) {
                    localItemData = localItemData[dispNameStruct[j]];
                }
                if (localItemData) {
                    displayText = localItemData[dispNameStruct[dispNameStruct.length - 1]];
                }else {
                    displayText = "Click to edit a group";
                }
            }

            //add
            this.addItem(this.getItemConfig(itemPath, {
                'itemDisplayText': displayText,
                'itemDisplayName': this.itemDisplayNames[detectedResourceType],
                'itemNumber': itemNumber
            }));
            itemNumber++;
        }

        this.fireEvent('loadcontent', this.record, path);
        this.contentLoaded = true;
    },

    /**
     * Used to grab the path where the dialog will be saved.
     * @param path
     */
    processPath: function (path) {
        this.path = path;
    },

    /**
     * Gets the path portion of the item prefix if one exists.
     * @returns {string}
     */
    getItemPrefixPath: function (resourceType) {
        var localItemPrefixParts = this.itemPrefixes[resourceType].parts;
        if (localItemPrefixParts.length <= 1) {
            return '';
        }

        return '/' + localItemPrefixParts.slice(0, localItemPrefixParts.length - 1).join('/');
    },

    /**
     * Gets the node name portion of the item prefix.
     * @returns {String|*}
     */
    getNodePrefix: function (resourceType) {
        var localItemPrefixParts = this.itemPrefixes[resourceType].parts;
        return localItemPrefixParts[localItemPrefixParts.length - 1];
    },

    /**
     * Will locate the property name to use for the display field from the dialog config.
     * @param itemConfig
     */
    findDisplayPropName: function (itemConfig) {
        var propName;

        if (itemConfig.itemDisplayId) {
            propName = this.findDisplayPropNameById(itemConfig.itemDisplayId, itemConfig.itemDialogConfig);
        } else if (itemConfig.itemDisplayName) {
            propName = itemConfig.itemDisplayName;
        } else if (itemConfig.itemDisplayPath) {
            propName = this.findDisplayPropNameByPath(itemConfig.itemDisplayPath);
        }

        return propName;
    },

    /**
     * Recursively looks by id in the provided dialog object for the property name that will contain the display value.
     * @param itemId
     * @param obj
     * @returns {string}
     */
    findDisplayPropNameById: function (itemId, obj) {
        //if our current object has the id, then this is where we should pull out our prop name
        if (obj && obj.itemId && obj.itemId == itemId) {
            return obj.name;
        } else {
            //recursively look for our prop name
            for (var k in obj) {
                if (obj.hasOwnProperty(k)) {
                    var v = obj[k];
                    if (v && ((typeof v === 'object' && v.xtype) || Object.prototype.toString.call(v) === '[object Array]')) {
                        var displayPropName = this.findDisplayPropNameById(itemId, v);
                        if (displayPropName) {
                            return displayPropName;
                        }
                    }
                }
            }
        }
    },

    /**
     * Locates the property name that will contain the display value by absolute path.
     * @param itemPath
     */
    findDisplayPropNameByPath: function (itemPath) {
        //first we need to get our dialog config directly as cq does additional processing to handle cq:WidgetCollection.
        var path = CQ.HTTP.externalize(itemPath + '.overlay.infinity.json');
        var refObj = CQ.Util.eval(path);
        return refObj.name;
    },

    /**
     * Generates a new data path where a new items data will be stored.
     * @param resourceType The resourceType to use for the new item.
     * @returns {string}
     */
    generateNewDataPath: function (resourceType) {
        //generate a new item id and construct our data path.
        var itemId = this.generateItemId();
        var localItemPrefix = this.itemPrefixes[resourceType].prefix;
        var dataPath = this.path + "/" + localItemPrefix + itemId;

        //create data node in jcr.
        /*
        CQ.HTTP.post(dataPath, null, {
            'sling:resourceType': resourceType,
            'jcr:created': '',
            'jcr:createdBy': '',
            'jcr:lastModified': '',
            'jcr:lastModifiedBy': ''
        });
*/
        //return data path
        return dataPath;
    },

    /**
     * Generates an item id for a new item.
     * @returns {number}
     */
    generateItemId: function () {
        var maxId = 0;
        this.itemsPanel.items.each(function (curItem) {
            if (maxId < curItem.itemId) {
                maxId = curItem.itemId;
            }
        });
        return maxId + 1;
    },

    /**
     * Gets the item id for the item represented by the dataPath provided.
     * @param dataPath
     * @param resourceType Used to determine the nodePrefix used for this data item.
     * @returns {Number}
     */
    retrieveItemId: function (dataPath, resourceType) {
        var nodeName = dataPath.substring(dataPath.lastIndexOf('/') + 1);
        return parseInt(nodeName.substring(this.getNodePrefix(resourceType).length));
    },

    /**
     * Gets the item config for the dataPath provided and the given defaults.
     * @param dataPath
     * @param defaults
     * @returns {*}
     */
    getItemConfig: function (dataPath, defaults) {
        var dataResourceType = null;
        var refObj = CQ.Util.eval(dataPath + '.json');
        if (refObj) {
            dataResourceType = refObj['sling:resourceType'];
        } else {
            dataResourceType = this.itemConfig[0].itemResourceType;
        }

        //clone our item config
        var localItemConfig = {};
        for (var i = 0; i < this.itemConfig.length; i++) {
            if (dataResourceType == this.itemConfig[i].itemResourceType) {
                localItemConfig = CQ.Ext.apply({}, this.itemConfig[i]);
            }
        }

        //apply provided defaults
        CQ.Util.applyDefaults(localItemConfig, defaults);

        //get our itemId from out dataPath
        var itemId = this.retrieveItemId(dataPath, dataResourceType);

        //assign the itemId dataPath to our item config
        localItemConfig.itemId = itemId;
        localItemConfig.dataPath = dataPath;

        //return our config
        return localItemConfig;
    },

    /**
     * Creates and adds a new item to our items panel.
     * @param config
     */
    addItem: function (config) {
        //if we are just under our limit, then hide our toolbar
        if (this.itemsPanel.items.getCount() + 1 == this.maxItems) {
            this.toolbar.hide();
        }

        //if we already hit our limit then just return
        if (this.itemsPanel.items.getCount() >= this.maxItems) {
            return;
        }

        //create and add our item
        var item = CQ.Util.build(config, true);
        this.itemsPanel.add(item);
        this.itemsPanel.doLayout();
    },

    /**
     * Removes an item from our panel and the jcr.
     * @param item
     */
    removeItem: function (item) {
        //post delete to jcr
        /*
        CQ.HTTP.post(item.dataPath, null, {
            ':operation': 'delete'
        });
        */

        this.removedItems.push(item.dataPath);

        if (!this.toolbar.isVisible()) {
            this.toolbar.show();
        }

        this.itemsPanel.remove(item);
        this.updateItemsPanel();
    },

    moveUp: function (item) {
        var index = this.itemsPanel.items.indexOf(item);
        if (index > 0) {
            //get the item name for the item we are swapping
            var swap = this.itemsPanel.items.itemAt(index - 1);
            var swapName = swap.dataPath.substring(swap.dataPath.lastIndexOf('/') + 1);

            var position = {}
            position.dp = item.dataPath;
            position.pos = 'before ' + swapName;
            this.itemPositions.push(position);


            //actually reorder our items in the ui
            var reorderMap = {};
            reorderMap[index - 1] = index;
            this.itemsPanel.items.reorder(reorderMap);

            //mark items as reordered so our ui can be updated properly
            swap.markReordered();
            item.markReordered();

            //update ui
            this.updateItemsPanel();
        }
    },

    moveDown: function (item) {
        var index = this.itemsPanel.items.indexOf(item);
        if (index < this.itemsPanel.items.getCount() - 1) {
            //get the item name for the item we are swapping
            var swap = this.itemsPanel.items.itemAt(index + 1);
            var swapName = swap.dataPath.substring(swap.dataPath.lastIndexOf('/') + 1);

            var position = {}
            position.dp = item.dataPath;
            position.pos = 'after ' + swapName;
            this.itemPositions.push(position);

            //reorder our item in the jcr
            /*
            CQ.HTTP.post(item.dataPath, null, {
                ':order': 'after ' + swapName
            });
            */

            //actually reorder our items
            var reorderMap = {};
            reorderMap[index + 1] = index;
            this.itemsPanel.items.reorder(reorderMap);

            //mark items as reordered so our ui can be updated properly
            swap.markReordered();
            item.markReordered();

            //update ui
            this.updateItemsPanel();
        }
    },

    updateItemsPanel: function () {
        for (var i = 0; i < this.itemsPanel.items.getCount(); i++) {
            this.itemsPanel.items.itemAt(i).setItemNumber(i + 1);
        }
        this.itemsPanel.doLayout();
    }
});

//todo - update the name once this is successfully pulled out the RWJF project (do not want to disturb existing functionality while we're doing this integration)
CQ.Ext.reg("velirmultidialogfield", VelirWidgets.MultiDialogField);