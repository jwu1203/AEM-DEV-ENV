//create widget namespace
CQ.Ext.ns('VelirWidgets');

VelirWidgets.MultiDialogField.Item = CQ.Ext.extend(CQ.Ext.Panel, {
	/**
	 * @cfg {String} itemDefaultDisplayText
	 * The default display text that will be used for the item.
	 */
	itemDefaultDisplayText: null,

	/**
	 * @cfg {String} itemDisplayId
	 * The ItemId of the widget whose value should be used in the item display field.
	 */
	itemDisplayId: null,

	/**
	 * @cfg {String} itemDisplayName
	 * The widget name that can be used to find the widget whose value should be used in the item display field.
	 * This is only used if itemDisplayId is left blank.
	 * This value can be hard set or dynamically calculated from the itemDisplayPath configuration.
	 */
	itemDisplayName: null,

	/**
	 * @cfg {String} itemDisplayPath
	 * The absolute path to the widget containing the value that should be used in the item display field.
	 * This is only used if itemDisplayId and itemDisplayName are left blank.  This is useful if you are using cqincludes for ootb components and you do not want to add an itemId to them.
	 */
	itemDisplayPath: null,

	/**
	 * @cfg {String} itemResourceType
	 * The sling:resourceType that should be used for each creted item (Defaults to foundation/components/image).
	 */
	itemResourceType: null,

	/**
	 * @cfg {Object} itemDialogConfig
	 * The dialog config to use for this item.
	 */
	itemDialogConfig: null,

	/**
	 * @cfg {String} dataPath
	 * The path to the data for our item.
	 */
	dataPath: null,

	/**
	 * The dialog that is created for and linked to this item.
	 * @type VelirWidgets.MultiDialogField.Item.Dialog
	 * @private
	 */
	itemDialog: null,

	/**
	 * The display field created for this item.
	 * @type CQ.Ext.form.DisplayField
	 * @private
	 */
	itemDisplayField: null,

	/**
	 * The display field used to display the item number.
	 * @type CQ.Ext.form.DisplayField
	 * @private
	 */
	itemNumberField: null,

    enableDialogSubmitOverride: null,

	constructor: function (config) {
		var that = this;

		//configure and apply any default configuration
		var defaults = {
			'layout': 'column',
			'bodyBorder': false,
			'style': 'padding-bottom:5px',
			'itemDefaultDisplayText': 'Click edit to configure.',
			'itemResourceType': 'foundation/components/image'
		};
		CQ.Util.applyDefaults(config, defaults);

		//create our display panel for displaying the item number.
		that.itemNumberField = CQ.Util.build({
			'value': config.itemNumber + '.',
			'xtype': 'displayfield',
			'style': 'padding-right:2px',
			'columnWidth': 0
		});

		//create our display panel here so we can pass a reference to our dialog for updates
		that.itemDisplayField = CQ.Util.build({
			'value': config.itemDisplayText || config.itemDefaultDisplayText,
			'xtype': 'displayfield',
			'columnWidth': 1
		});

		//add items
		config.items = [
			that.itemNumberField,
			that.itemDisplayField,
			{
				'text': 'Edit ' + VelirWidgets.MultiDialogFieldUtil.getItemFriendlyTitle(config),
				'xtype': 'textbutton',
				'style': 'padding-left:2px;padding-right:2px;text-align:center;',
				'columnWidth': 0,
				'handler': function () {
					that.showDialog();
				}
			},
			{
				'xtype': 'button',
				'iconCls': 'cq-multifield-up',
				'style': 'padding-left:2px;padding-right:2px;',
				'columnWidth': 0,
				'template': new CQ.Ext.Template('<span><button class="x-btn" type="{0}"></button></span>'),
				'handler': function () {
					var parent = that.getParentField();
					parent.moveUp(that);
				}
			},
			{
				'xtype': 'button',
				'iconCls': 'cq-multifield-down',
				'style': 'padding-left:2px;padding-right:2px;',
				'columnWidth': 0,
				'template': new CQ.Ext.Template('<span><button class="x-btn" type="{0}"></button></span>'),
				'handler': function () {
					var parent = that.getParentField();
					parent.moveDown(that);
				}
			},
			{
				'xtype': 'button',
				'iconCls': 'cq-multifield-remove',
				'style': 'padding-left:2px;padding-right:2px;',
				'columnWidth': 0,
				'template': new CQ.Ext.Template('<span><button/> class="x-btn" type="{0}"></button></span>'),
				'handler': function () {
					var parent = that.getParentField();
					parent.removeItem(that);
				}
			}
		];

        VelirWidgets.MultiDialogField.Item.superclass.constructor.call(this, config);
	},

	initComponent: function () {
        this.enableDialogSubmitOverride = true;
        VelirWidgets.MultiDialogField.Item.superclass.initComponent.call(this);
	},

	showDialog: function () {
        if (!this.itemDialog) {
            this.itemDialog = CQ.WCM.getDialog(this.getDialogConfig(), this.getDialogKey());
            this.itemDialog.loadContent(this.dataPath);
        }

        var that = this;

        var beforeSubmitDialog = function(dialog) {

            if (that.enableDialogSubmitOverride) {
                //close the dialog
                var config = {};
                dialog[dialog.closeAction]();

                //stop submitting the dialog
                return false;
            } else {
                return true;
            }
        }

        this.mon(this.itemDialog, 'beforesubmit', beforeSubmitDialog, null, null);

		this.itemDialog.show();
	},

	getDialogConfig: function () {
		var that = this;

		//clone our dialog config
		var dialogConfig = CQ.Ext.apply({}, that.itemDialogConfig);
		CQ.Util.applyDefaults(dialogConfig, {
			'modal': true,
			'params': {
				'./jcr:lastModified': '',
				'./jcr:lastModifiedBy': ''
			}
		});

		//set up custom ok button.
		dialogConfig.buttons = [
			{
				'text': 'OK',
				'width': '80px',
				'xtype': 'button',
				'handler': function () {
					var dialog = this;

					//if we have an item display id, then try to find a value to use.
					if (that.itemDisplayId || that.itemDisplayName) {
						var displayWidget = dialog.findBy(function (comp) {
							if (that.itemDisplayId) {
								return comp.itemId == that.itemDisplayId;
							} else if (comp.name && that.itemDisplayName) {
								return comp.name.replace('./', '') == that.itemDisplayName.replace('./', '');
							}
						})[0];

						//If no displayWidget, try to pull value from the raw dialog form.
						if (!displayWidget && that.itemDisplayName) {
							displayWidget = this.form.findField(that.itemDisplayName);
						}

						if (displayWidget) {
							that.updateDisplayText(displayWidget.getValue());
						}
					}

					dialog.ok();
				}
			},
			CQ.Dialog.CANCEL
		];

		return dialogConfig;
	},

	getDialogKey: function () {
		return "editdialog-" + this.dataPath;
	},

	getParentField: function () {
		return this.findParentBy(function (container) {
			return container.xtype == 'velirmultidialogfield';
		});
	},

	markReordered: function () {
		this.reordered = true;
	},

	setItemNumber: function (itemNumber) {
		this.itemNumber = itemNumber;
		this.itemNumberField.setValue(itemNumber + '.');
	},

	updateDisplayText: function (displayText) {
		if (displayText && displayText != '') {
			this.itemDisplayField.setValue(displayText);
		} else {
			this.itemDisplayField.setValue(this.itemDefaultDisplayText);
		}
	},

	destroy: function () {
		if (this.itemDialog) {
			CQ.WCM.unregisterDialog(this.getDialogKey());
			this.itemDialog.destroy();
		}

		VelirWidgets.MultiDialogField.Item.superclass.destroy.call(this);
	}
});


CQ.Ext.reg("velirmultidialogfield.item", VelirWidgets.MultiDialogField.Item);