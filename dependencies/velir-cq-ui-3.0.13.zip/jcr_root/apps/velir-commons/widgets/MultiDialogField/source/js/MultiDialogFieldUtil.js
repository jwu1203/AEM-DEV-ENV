//create widget namespace
CQ.Ext.ns('VelirWidgets');

VelirWidgets.MultiDialogFieldUtil = {
	/**
	 * Gets the friendly title from the itemConfig provided.
	 * @param itemConfig
	 * @returns {String}
	 */
	getItemFriendlyTitle: function (itemConfig) {
		if (itemConfig.itemTitle) {
			return itemConfig.itemTitle;
		}

		if (itemConfig.itemResourceType) {
			return itemConfig.itemResourceType.substring(itemConfig.itemResourceType.lastIndexOf('/') + 1);
		}

		return '';
	}
};