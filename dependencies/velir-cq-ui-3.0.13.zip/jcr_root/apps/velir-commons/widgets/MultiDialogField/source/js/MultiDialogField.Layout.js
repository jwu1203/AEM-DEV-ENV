//create widget namespace
CQ.Ext.ns('VelirWidgets');

VelirWidgets.MultiDialogField.Layout = CQ.Ext.extend(CQ.Ext.layout.ContainerLayout, {
	type: 'velirmultidialogfielditems',

	monitorResize: true,

	renderAll: function (ct, target) {
		var items = ct.items.items;
		for (var i = 0; i < items.length; i++) {
			var c = items[i];
			if (c && c.rendered && c.reordered) {
				target.dom.removeChild(c.el.dom);
				c.reordered = false;
			}
		}

		VelirWidgets.MultiDialogField.Layout.superclass.renderAll.call(this, ct, target);
	},

	renderItem: function (c, position, target) {
		if (c && c.rendered && c.reordered) {
			target.dom.removeChild(c.el.dom);
			c.reordered = false;
		}

		VelirWidgets.MultiDialogField.Layout.superclass.renderItem.call(this, c, position, target);
	},

	onLayout: function (ct, target) {
		VelirWidgets.MultiDialogField.Layout.superclass.onLayout.call(this, ct, target);
		var cs = this.getRenderedItems(ct), len = cs.length, i, c;
		for (i = 0; i < len; i++) {
			c = cs[i];
			if (c.doLayout) {
				// Shallow layout children
				c.doLayout(true);
			}
		}
	}
});

CQ.Ext.Container.LAYOUTS['velirmultidialogfielditems'] = VelirWidgets.MultiDialogField.Layout;
