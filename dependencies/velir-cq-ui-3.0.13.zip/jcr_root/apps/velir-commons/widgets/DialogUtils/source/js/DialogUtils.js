/**
 * Convenient function to manipulate dialog
 * @author Sebastien Bernard
 */

CQ.Ext.ns('VelirWidgets');

VelirWidgets.DialogUtils = {
	enableComponents: function (currentComp, compIdToEnable) {
		var compFounds = VelirWidgets.DialogUtils.findComponents(currentComp, compIdToEnable);
		for (var j = 0; j < compFounds.length; j++) {
			compFounds[j].disable();
		}
	},

	disableComponents: function (currentComp, compIdToDisable) {
		var compFounds = VelirWidgets.DialogUtils.findComponents(currentComp, compIdToDisable);
		for (var j = 0; j < compFounds.length; j++) {
			compFounds[j].enable();
		}
	},

	showComponents: function (currentComp, compIdToEnable) {
		var compFounds = VelirWidgets.DialogUtils.findComponents(currentComp, compIdToEnable);
		for (var j = 0; j < compFounds.length; j++) {
			compFounds[j].show();
		}
	},

	hideComponents: function (currentComp, compIdToDisable) {
		var compFounds = VelirWidgets.DialogUtils.findComponents(currentComp, compIdToDisable);
		for (var j = 0; j < compFounds.length; j++) {
			compFounds[j].hide();
		}
	},

	resetComponents: function (currentComp, compIdToDisable) {
		var compFounds = VelirWidgets.DialogUtils.findComponents(currentComp, compIdToDisable);
		for (var j = 0; j < compFounds.length; j++) {
			compFounds[j].reset();
		}
	},

	allowBlankComponents: function (currentComp, compIdToDisable, allowBlank) {
		var compFounds = VelirWidgets.DialogUtils.findComponents(currentComp, compIdToDisable);
		for (var j = 0; j < compFounds.length; j++) {
			compFounds[j].allowBlank = allowBlank;
		}
	},

	findComponents: function (currentComp, compIds) {
		var dialog = currentComp.findParentByType("dialog");
		var compFounds = [];
		if (dialog) {
			for (var i = 0; i < compIds.length; i++) {
				var compFoundsByName = dialog.find("name", compIds[i]);
				var compFoundsByItemId = dialog.find("itemId", compIds[i]);
				var compFoundsById = dialog.find("id", compIds[i]);
				compFounds = compFounds.concat(compFoundsByName).concat(compFoundsByItemId).concat(compFoundsById);
			}
		}
		return compFounds;
	}
};