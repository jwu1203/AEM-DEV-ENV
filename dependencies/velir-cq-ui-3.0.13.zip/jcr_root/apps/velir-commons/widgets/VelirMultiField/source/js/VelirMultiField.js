(function () {

//create widget namespace
CQ.Ext.ns('VelirWidgets');

// do this so that we can use the same code for differently-named functions and refer to the enclosing object before
var validationFunction = function () {
    var superValid = VelirWidgets.VelirMultiField.superclass.isValid.call(this);
    var count = this.items.getCount();
    return superValid && (count >= this.minItems + 1);
};

/**
 * Widget that extends multifield that allows a maximun # of items
 * @type {*}
 */
VelirWidgets.VelirMultiField = CQ.Ext.extend(CQ.form.MultiField, {
    /**
     * @cfg {Number} maxItems
     * Max number of items. 0 or -1 to have no maxinum # of itesm.
     */
    maxItems: -1,
    minItems: -1,

	addItem : function(value) {
		VelirWidgets.VelirMultiField.superclass.addItem.call(this, value);
		var count = this.items.getCount();
		if(this.maxItems > 0 && count - 1 >= this.maxItems){
			//Add panel should be the last entry
			var addPanel = this.items.get(count - 1);
			if(addPanel && !addPanel.hidden){
				addPanel.hide();
			}
		}
	},

    markInvalid : function(msg){
        VelirWidgets.VelirMultiField.superclass.markInvalid(msg);
    },

	removedItem : function(){
		var count = this.items.getCount();
		if(count <= this.maxItems){
			//Add panel should be the last entry
			var addPanel = this.items.get(count - 1);
			if(addPanel && addPanel.hidden){
				addPanel.show();
			}
		}
	},
    isValid : validationFunction,
	validate : validationFunction,

    constructor : function(config) {
        // set default values
        if (typeof config.maxItems === "undefined") {
            config.maxItems = -1;
        }
        if (typeof config.minItems === "undefined") {
            config.minItems = -1;
        }

        VelirWidgets.VelirMultiField.superclass.constructor.call(this, config);
    },

    initComponent : function() {
        VelirWidgets.VelirMultiField.superclass.initComponent.call(this);
		this.addListener("removeditem", this.removedItem, this);
    }
});

CQ.Ext.reg("velirmultifield", VelirWidgets.VelirMultiField);

})();