//create widget namespace
CQ.Ext.ns('VelirWidgets.rte');

//create our custom deserializer
VelirWidgets.rte.deserializer = new Class({

	toString: "VelirHtmlDeserializer",

	extend: CUI.rte.HtmlDeserializer,

	_init: function (config) {
		config = config || {};
		CUI.rte.Utils.applyDefaults(config, {
			"whitelist": VelirWidgets.rte.SERIALIZER_WHITE_LIST
		});

		this.whitelist = config.whitelist;
		this.inherited(arguments);
	},

	isAllowed: function (tagName) {
		return CQ.form.rte.Common.arrayContains(this.whitelist, tagName.toLowerCase());
	},

	handlePreformattedSections: function (context, rootDom) {
		//if our root dom is undefined then just return
		if (rootDom == undefined) {
			return;
		}

		//if our tag isn't allowed, rip out its children, add them to our parent
		if (rootDom.nodeType == 1 && !this.isAllowed(rootDom.tagName)) {
			//get our parent node
			var parentNode = rootDom.parentNode;

			//find our next sibling
			var nextSibling = null;
			for (var i = 0; i < parentNode.childNodes.length; i++) {
				//if we found our current node and we have an additional node, pull out the next node.
				if (parentNode.childNodes[i] == rootDom && i < parentNode.childNodes.length - 1) {
					nextSibling = parentNode.childNodes[i + 1];
					break;
				}
			}

			//rip out child nodes
			var childNodes = rootDom.childNodes;

			//remove our node
			parentNode.removeChild(rootDom);

			//go through each child node and add to our parent
			for (var i = 0; i < childNodes.length; i++) {
				if (nextSibling != null) {
					parentNode.insertBefore(childNodes[i], nextSibling);
				} else {
					parentNode.appendChild(childNodes[i]);
				}
			}

			//go again through each child node and process
			for (var i = 0; i < childNodes.length; i++) {
				this.handlePreformattedSections(context, childNodes[i]);
			}
		} else {
			//just perform default logic
			this.inherited(arguments);
		}
	}
});
