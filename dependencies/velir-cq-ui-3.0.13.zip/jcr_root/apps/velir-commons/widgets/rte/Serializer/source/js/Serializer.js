//create widget namespace
CQ.Ext.ns('VelirWidgets.rte');

VelirWidgets.rte.SERIALIZER_WHITE_LIST = ['body', 'p', 'h1', 'h2', 'h3', 'ul', 'ol', 'li', 'a', 'blockquote', 'b', 'i', 'u', 'em', 'strong', 'br', 'sup', 'span'];

//create our custom serializer
VelirWidgets.rte.serializer = new Class({

	toString: "VelirHtmlSerializer",

	extend: CUI.rte.HtmlSerializer,

	_init: function (config) {
		config = config || {};
		//define our default configuration.
		CUI.rte.Utils.applyDefaults(config, {
			"whitelist": VelirWidgets.rte.SERIALIZER_WHITE_LIST
		});
		this.whitelist = config.whitelist;
		this.inherited(arguments);
	},

	isAllowed: function (tagName) {
		return CQ.form.rte.Common.arrayContains(this.whitelist, tagName.toLowerCase());
	},

	serializeNodeEnter: function (dom) {
		//if our tag isn't allowed, return empty string
		if (dom.nodeType == 1 && !this.isAllowed(dom.tagName)) {
			return '';
		} else {
			return this.inherited(arguments);
		}
	},

	serializeNodeLeave: function (dom) {
		//if our tag isn't allowed, return empty string
		if (dom.nodeType == 1 && !this.isAllowed(dom.tagName)) {
			return '';
		} else {
			return this.inherited(arguments);
		}
	},

	serializeTextNode: function (dom) {
		var s = this.inherited(arguments);
		s = s.replace(/\u201A/g, "&lsquo;");
		s = s.replace(/\u201e/g, '&rdquo;');
		s = s.replace(/\u02C6/g, '^');
		s = s.replace(/\u2039/g, '&gt;');
		s = s.replace(/\u203A/g, '&lt;');
		s = s.replace(/\u2026/g, '...');
		s = s.replace(/[\u02DC|\u00A0]/g, "&nbsp;");
		return s;
	}
});