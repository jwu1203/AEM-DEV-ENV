//create widget namespace
CQ.Ext.ns('VelirWidgets.rte.plugins');

//create our custom deserializer
VelirWidgets.rte.plugins.LinkPlugin = new Class({
	/**
	 * The read more modifier responsible for detecting/adding/removing the read more treatment on our links.
	 * @private
	 */
	readMoreModifier: null,

	toString: "VelirLinkPlugin",

	extend: CUI.rte.plugins.LinkPlugin,

	getFeatures: function () {
		return [ "modifylink", "unlink", "anchor" ];
	},

	notifyPluginConfig: function (pluginConfig) {
		this.inherited(arguments);

		this.config = this.config || { };

		//create read more modifier and provide to dialog.
		this.readMoreModifier = VelirWidgets.rte.plugins.ReadMoreLinkModifier.newInstance(this.config.readMoreHtml, this.config.readMoreClass, this.config.readMoreStyle);
		if (this.config.linkDialogConfig && this.config.linkDialogConfig.hasReadMore) {
			this.config.linkDialogConfig.readMoreModifier = this.readMoreModifier;
		}
	},

	applyLink: function (context) {
		var com = CUI.rte.Common;
		var linkObj = this.linkDialog.objToEdit;
		if (linkObj) {
			var linkUrl = linkObj.href;
			var cssClass = linkObj.cssClass;
			var target = linkObj.target;
			var readMore = linkObj.readMore;
			if (com.ua.isIE) {
				this.savedRange.select();
			}
			this.editorKernel.relayCmd("velirmodifylink", {
				"url": linkUrl,
				"css": cssClass,
				"target": target,
				"readMoreModifier": this.readMoreModifier,
				"readMore": readMore,
				"trimLinkSelection": this.config.trimLinkSelection,
				"attributes": linkObj.attributes
			});
		}
	},

	execute: function (cmd, value, env) {
		if (cmd == "unlink") {
			this.editorKernel.relayCmd(cmd, {
				"readMoreModifier": this.readMoreModifier
			});
			return;
		}

		this.inherited(arguments);
	}
});

// register plugin
CUI.rte.plugins.PluginRegistry.register("velirlinks", VelirWidgets.rte.plugins.LinkPlugin);