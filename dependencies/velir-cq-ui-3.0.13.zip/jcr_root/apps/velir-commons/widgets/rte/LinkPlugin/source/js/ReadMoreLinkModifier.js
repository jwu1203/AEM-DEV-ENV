//create namespace
CQ.Ext.ns('VelirWidgets.rte.plugins');

VelirWidgets.rte.plugins.ReadMoreLinkModifier = function () {
	var com = CUI.rte.Common;

	var newInstance = function (readMoreHtml, readMoreClass, readMoreStyle) {
		var wrappingHtml = ' <span style="font-size: 0.7em;">' + CQ.Ext.util.Format.htmlEncode(readMoreHtml) + '</span>';

		/**
		 * Detects if a link already has the read more html.
		 * @param link
		 * @returns {boolean}
		 * @private
		 */
		var hasReadMoreHtml = function (link) {
			return readMoreHtml && com.strEndsWith(removeWhitespace(link.innerHTML), removeWhitespace(wrappingHtml));
		};

		/**
		 * Detects if a link already has the read more class.
		 * @param link
		 * @returns {boolean}
		 * @private
		 */
		var hasReadMoreClass = function (link) {
			return readMoreClass && com.hasCSS(link, readMoreClass);
		};

		/**
		 * Detects if a link already has the read more style.
		 * @param link
		 * @returns {boolean}
		 * @private
		 */
		var hasReadMoreStyle = function (link) {
			var styleAttr = com.getAttribute(link, 'style', true);
			return readMoreStyle && styleAttr && removeWhitespace(styleAttr) === removeWhitespace(readMoreStyle);
		};

		/**
		 * Will remove all whitespace from the provided text.
		 * @param text
		 * @returns {*}
		 */
		var removeWhitespace = function (text) {
			if (!text) {
				return text;
			}

			return text.replace(/\s/g, '');
		};

		//return internal public object
		return {
			/**
			 * Detects if link already has the read more treatment.
			 * @returns {boolean}
			 */
			hasReadMore: function (link) {
				if (!link) {
					return false;
				}

				//return true if any of our read more treatment methods is applied to the link
				return hasReadMoreHtml(link) || hasReadMoreClass(link) || hasReadMoreStyle(link);
			},

			/**
			 * Will apply read more treatment to our link.  Will not apply if treatment is already added.
			 */
			applyReadMore: function (link) {
				//if we have a read more character configured and it isn't already applied, append the html
				if (readMoreHtml && !hasReadMoreHtml(link)) {
					link.innerHTML = link.innerHTML + wrappingHtml;
				}

				//if we have a read more class configured and it isn't already applied, apply css class
				if (readMoreClass && !hasReadMoreClass(link)) {
					com.addClass(link, readMoreClass)
				}

				//if we have a read more style configured and it isn't already applied, apply it
				if (readMoreStyle && !hasReadMoreStyle(link)) {
					com.setAttribute(link, 'style', readMoreStyle);
				}
			},

			/**
			 * Will remove read more treatment to our link.  Will not remove if treatment doesn't exist.
			 */
			removeReadMore: function (link) {
				//if we have a read more character configured and it is applied, remove that from link text
				if (readMoreHtml && hasReadMoreHtml(link)) {
					link.innerHTML = link.innerHTML.substr(0, link.innerHTML.length - wrappingHtml.length);
				}

				//remove css class if configured and is applied
				if (readMoreClass && hasReadMoreClass(link)) {
					com.removeClass(link, readMoreClass);
				}

				//remove style if configured and is applied
				if (readMoreStyle && hasReadMoreStyle(link)) {
					com.removeAttribute(link, 'style');
				}
			}
		}
	};

	return {
		'newInstance': newInstance
	};
}();