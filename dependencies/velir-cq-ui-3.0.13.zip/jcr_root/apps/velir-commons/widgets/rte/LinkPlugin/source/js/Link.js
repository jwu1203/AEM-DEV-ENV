//create widget namespace
CQ.Ext.ns('VelirWidgets.rte.commands');

//create our custom deserializer
VelirWidgets.rte.commands.Link = new Class({

	toString: "VelirLink",

	extend: CUI.rte.commands.Link,

	_init: function (config) {
		this.inherited(arguments);
	},

	addLinkToDom: function (execDef) {
		var context = execDef.editContext;
		var nodeList = execDef.nodeList;
		var url = execDef.value.url;
		var styleName = execDef.value.css;
		var target = execDef.value.target;
		var attributes = execDef.value.attributes || { };
		var readMoreModifier = execDef.value.readMoreModifier;
		var readMore = execDef.value.readMore;
		var links = [ ];
		nodeList.getAnchors(context, links, true);
		if (links.length > 0) {
			// modify existing link(s)
			for (var i = 0; i < links.length; i++) {
				this.applyLinkProperties(links[i].dom, url, styleName, target, attributes);

				if (readMore === true) {
					readMoreModifier.applyReadMore(links[i].dom);
				} else {
					readMoreModifier.removeReadMore(links[i].dom);
				}
			}
		} else {
			// create new link
			var sel = CUI.rte.Selection;
			var dpr = CUI.rte.DomProcessor;
			if (execDef.value.trimLinkSelection === true) {
				var range = sel.getLeadRange(context);
				range = sel.trimRangeWhitespace(context, range);
				sel.selectRange(context, range);
				nodeList = dpr.createNodeList(context, sel.createProcessingSelection(
					context));
			}
			// handle HREF problems on IE with undo (IE will deliberately change the
			// HREF, causing the undo mechanism to fail):
			var helperSpan = context.createElement("span");
			helperSpan.innerHTML = "<a href=\"" + url + "\"></a>";
			attributes.href = helperSpan.childNodes[0].href;
			attributes[CUI.rte.Common.HREF_ATTRIB] = url;
			if (styleName) {
				attributes.className = styleName;
			}
			if (target) {
				attributes.target = target;
			} else {
				delete attributes.target;
			}
            attributes["data-analytics-content-id"] = this.getDataAnalyticsContentId(url);
			for (var key in attributes) {
				if (attributes.hasOwnProperty(key)) {
					var attribValue = attributes[key];
					if ((attribValue == null) || (attribValue.length == 0)
						|| (attribValue == CUI.rte.commands.Link.REMOVE_ATTRIBUTE)) {
						delete attributes[key];
					}
				}
			}
			var newLinks = nodeList.surround(context, "a", attributes);
			for (var i = 0; i < newLinks.length; i++) {
				if (readMore === true) {
					readMoreModifier.applyReadMore(newLinks[i]);
				}
			}
		}
	},

    getDataAnalyticsContentId :  function(url) {
        var uuid = "ext";

        function formatUuid(uuid) {
            return "00000000".concat(uuid).slice(-8)
        }
        CQ.Log.debug("Get uuid from url: " + url);
        if(url.indexOf("/") == 0){
            var jsonJcrContentUrl = url.replace(".html","/_jcr_content.json");
            var jcrContent = CQ.HTTP.eval(CQ.HTTP.get(jsonJcrContentUrl))
                if(jcrContent && jcrContent.analyticsUUID){
                    uuid = formatUuid(jcrContent.analyticsUUID);
                }
        }
        CQ.Log.debug("Uuid for url: " + url + " is " + uuid);
        return uuid;
    },

	removeLinkFromDom: function (execDef) {
		var context = execDef.editContext;
		var nodeList = execDef.nodeList;
		var readMoreModifier = execDef.value.readMoreModifier;
		var links = [ ];
		nodeList.getAnchors(context, links, true);
		for (var i = 0; i < links.length; i++) {
			readMoreModifier.removeReadMore(links[i].dom);
		}

		this.inherited(arguments);
	},

	execute: function (execDef) {
		switch (execDef.command.toLowerCase()) {
			case "velirmodifylink":
				this.addLinkToDom(execDef);
				break;
		}

		this.inherited(arguments);
	}
});

// register commands
CUI.rte.commands.CommandRegistry.register("velirmodifylink", VelirWidgets.rte.commands.Link);
CUI.rte.commands.CommandRegistry.register("unlink", VelirWidgets.rte.commands.Link);
