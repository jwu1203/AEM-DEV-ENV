//create widget namespace
CQ.Ext.ns('VelirWidgets.rte.plugins');

VelirWidgets.rte.plugins.LinkDialog = CQ.Ext.extend(CQ.form.rte.plugins.LinkDialog, {
	/**
	 * @cfg {String} readMoreModifier
	 * The modifier used to apply read more treatment to our links.
	 */
	readMoreModifier: null,

	constructor: function (config) {
		config = config || { };
		var defaults = {
			"title": CQ.I18n.getMessage("Hyperlink"),
			"modal": true,
			"width": 400,
			"height": 230,
			"dialogItems": [
				{
					"itemId": "href",
					"name": "href",
					"parBrowse": false,
					"anchor": CQ.themes.Dialog.ANCHOR,
					"fieldLabel": CQ.I18n.getMessage("Link to"),
					"xtype": "protectedpathfield",
					"ddGroups": [
						CQ.wcm.EditBase.DD_GROUP_PAGE,
						CQ.wcm.EditBase.DD_GROUP_ASSET
					],
					"fieldDescription": CQ.I18n.getMessage("Drop files or pages from the Content Finder"),
					"listeners": {
						"dialogselect": {
							"fn": this.selectAnchor,
							"scope": this
						},
						"render": this.initHrefDragAndDrop
					},
					"validator": this.validateLink.createDelegate(this),
					"validationEvent": "keyup",
					"escapeAmp": true
				},
				{
					"itemId": "targetBlank",
					"name": "targetBlank",
					"xtype": "checkbox",
					"boxLabel": CQ.I18n.getMessage("Open in new window"),
					"value": "targetBlank"
				},
				{
					"itemId": "readMore",
					"name": "readMore",
					"xtype": "checkbox",
					"boxLabel": "Call to Action Link",
					"fieldDescription": "Use only on links that are on their own line of text",
					"value": "readMore"
				}
			]
		};
		CQ.Util.applyDefaults(config, defaults);
		VelirWidgets.rte.plugins.LinkDialog.superclass.constructor.call(this, config);
	},

	dlgFromModel: function () {
		var readmoreField = this.getFieldByName("readMore");
		if (readmoreField) {
			readmoreField.setValue(this.readMoreModifier.hasReadMore(this.objToEdit.dom));
		}
		VelirWidgets.rte.plugins.LinkDialog.superclass.dlgFromModel.call(this);
	},

	dlgToModel: function () {
		if (this.objToEdit) {
			var readmoreField = this.getFieldByName("readMore");
			if (readmoreField) {
				this.objToEdit.readMore = readmoreField.getValue() === true;
			}
		}
		VelirWidgets.rte.plugins.LinkDialog.superclass.dlgToModel.call(this);
	}
});

// register LinkDialog component as xtype
CQ.Ext.reg("velirlinkdialog", VelirWidgets.rte.plugins.LinkDialog);
